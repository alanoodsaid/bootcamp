"""
Write a Python function that takes a string as input and returns the
string in reverse order. You should use the Stack class to implement the
solution.
"""
from Stach import stach
def reverse_string(input_string):
    stack=Stack()
    for char in input_string:
        stack.push(char)
        reversed_string = ""
        
        while not stack.is_empty():
            reversed_string += stack.pop()
            
        return reversed_string
    
print(reversed_string("hello")
            