import pandas as pd
from Product import Product  # Make sure the 'Product' class is defined in 'Product.py'

# Assuming you already have data in the 'Reading.xlsx' file
df = pd.read_excel('Reading.xlsx', sheet_name='Products')

print("%-20s%-20s%-10s" % ("Product Name", "Category", "Price"))
print("-" * 50)

pList = []

for index, row in df.iterrows():
    productName = row['pName']
    category = row['Category']
    price = row['Price']

    currentProduct = Product(productName, category, price)
    pList.append(currentProduct)

    # Apply a discount of 5% to the current product
    currentProduct.discount(5)

    print("%-20s%-20s%-10.2f" % (productName, category, currentProduct.getPrice()))

print(len(pList))
for product in pList:
    print("%-20s%-20s%-10.2f" % (product.getName(), product.getCategory(), product.getPrice()))
