class Employee:
    def __init__(self, name, age, department, salary):
        self.name = name
        self.age = age
        self.department = department
        self.salary = salary

def add_employee(employees_list, employee):
    employees_list.append(employee)
    print(f"{employee.name} has been added to the Employee Management System.")

def remove_employee(employees_list, employee_name):
    removed = False
    for employee in employees_list:
        if employee.name == employee_name:
            employees_list.remove(employee)
            print(f"{employee.name} has been removed from the Employee Management System.")
            removed = True
            break

    if not removed:
        print(f"Employee with name '{employee_name}' not found in the system.")

def view_employees(employees_list):
    if not employees_list:
        print("No employees found in the system.")
        return

    print("Employee list:")
    for employee in employees_list:
        print(f"Name: {employee.name}, Age: {employee.age}, Department: {employee.department}, Salary: {employee.salary}")


employees = []

emp1 = Employee("Alanood", 23, "IT", 1000)
emp2 = Employee("Said", 26, "IT", 2000)
emp3 = Employee("Aisha", 31, "HR", 900)

add_employee(employees, emp1)
add_employee(employees, emp2)
add_employee(employees, emp3)

remove_employee(employees, "Said")

view_employees(employees)
