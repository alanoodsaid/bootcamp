'''
Check Palindrome

Write a Python function that takes a string as input and checks whether
the string is a palindrome or not. A palindrome is a word, phrase,
number, or sequence that reads the same backward as forward.

Your task is to implement the is_palindrome function that checks
whether the given string is a palindrome or not. The function should
return True if the string is a palindrome, and False otherwise.
'''
from QueueClass import Queue
def palindrome(input_string):
    cleaned_string=''
    for char in input_string:
        if char.isalnum():
            cleaned_string=cleaned_string+char.lower()
            
        return cleaned_string==cleaned_string[::-1]
input_string = input("Enter a string: ")
if palindrome(input_string):
    print(f"{input_string} is a palindrome.")
else:
    print(f"{input_str} is not a palindrome.")
            