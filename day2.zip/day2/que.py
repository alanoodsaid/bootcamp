'''
Check Palindrome

Write a Python function that takes a string as input and checks whether
the string is a palindrome or not. A palindrome is a word, phrase,
number, or sequence that reads the same backward as forward.

Your task is to implement the is_palindrome function that checks
whether the given string is a palindrome or not. The function should
return True if the string is a palindrome, and False otherwise.
'''
from QueueClass import Queue
def palindrome(input_strint):
    cleaned_string=''
    for char in