from Stack import Stack 
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

class Stack:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return len(self.items) == 0

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()

    def peek(self):
        if not self.is_empty():
            return self.items[-1]

    def size(self):
        return len(self.items)

def add_guest(guest_list, person):
    guest_list.push(person)
    print(f"{person.name} has been added to the guest list.")

def remove_guest(guest_list):
    if not guest_list.is_empty():
        removed_guest = guest_list.pop()
        print(f"{removed_guest.name} has been removed from the guest list.")
    else:
        print("The guest list is empty.")

def get_guest_count(guest_list):
    count = guest_list.size()
    print(f"Total number of guests: {count}")

def view_guests(guest_list):
    print("Guest list:")
    for guest in guest_list.items[::-1]:
        print(guest.name)


guest_list = Stack()

p1 = Person("Alanood", 23)
p2 = Person("Aisha", 22)
p3 = Person("Malak", 22)

add_guest(guest_list, p1)
add_guest(guest_list, p2)
add_guest(guest_list, p3)

get_guest_count(guest_list)

view_guests(guest_list)

remove_guest(guest_list)

view_guests(guest_list)
