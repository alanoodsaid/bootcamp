import csv

file_path = 'student.csv'
gpa_list = []

with open(file_path, 'r') as csvfile:
    csvreader = csv.DictReader(csvfile)
    for row in csvreader:
        gpa_list.append(float(row['GPA']))

average_gpa = sum(gpa_list) / len(gpa_list)
print(f"Average GPA: {average_gpa:.2f}")
print(gpa_list)
# Get information for a new student
new_student_name = input("Enter the new student's name: ")
new_student_age = input("Enter the new student's age: ")
new_student_gpa = float(input("Enter the new student's GPA: "))

# Step 3: Insert the new GPA into the list
gpa_list.insert(2, new_student_gpa)


print(gpa_list)
