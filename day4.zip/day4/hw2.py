import json

# Step 1: Read the JSON file and load its contents
def load_data(filename):
    try:
        with open('countries.json', 'r') as file:
            data = json.load(file)
        return data
    except FileNotFoundError:
        return []

# Step 2: Allow the user to input new country information and add it to the JSON data
def add_country(data, name, population):
    new_country = {
        'name': name,
        'population': population
    }
    data.append(new_country)
    return data

# Step 3: Allow the user to search for and delete a country from the JSON data
def delete_country(data, name):
    country_found = False
    updated_data = []

    for country in data:
        if country['name'].lower() == name.lower():
            country_found = True
        else:
            updated_data.append(country)

    if country_found:
        return updated_data, True
    else:
        return data, False


# Step 4: Write the updated JSON data back to the file
def save_data(data, filename):
    with open(filename, 'w') as file:
        json.dump(data, file, indent=4)

def main():
    filename = 'countries.json'
    data = load_data(filename)

    while True:
        print("1. Add country")
        print("2. Delete country")
        print("3. Exit")
        choice = input("Select an option: ")

        if choice == '1':
            name = input("Enter country name: ")
            population = input("Enter population: ")
            data = add_country(data, name, population)
            save_data(data, filename)
            print("Country added successfully!")

        elif choice == '2':
            name = input("Enter country name to delete: ")
            data, country_deleted = delete_country(data, name)
            if country_deleted:
                save_data(data, filename)
                print("Country deleted successfully!")
            else:
                print("Country not found.")

        elif choice == '3':
            break

        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()
