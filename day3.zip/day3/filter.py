'''
def is_even(L):
    evenList = []
    for num in L:
        if num%2 == 0:
            evenList.append(num)
        return evenList
numbers = [10, 2 ,3 ,14 , 17, 29, 30 , 22, 9 , 16]
evens = is_even(numbers)
print(" numbers: ", numbers)
print("even numbers: ", evens)

evenUsingFilter = list(filter(lambda n:%2==0 ,numbers))
rint("filterd even : ", evenUsingFilter)
'''
import re

a = ["dog", "cat", "wildcat", "thundercat", "cow", "hooo"]
pattern = re.compile(r'cat')

result = list(filter(lambda word: pattern.search(word), a))
print(result)

    