'''
f=  lambda a,n: a * n
result = f(3,11)
print (result)

''''''''''''
def oddeven(n):
    if n%2 ==0 :
        return 'even'
    else:
        return 'odd'
    
''''''''''''''
'''
OddEven = lambda n:(n%2 and "ODD" or "EVEN")

print(OddEven(14))
print(OddEven(19))
