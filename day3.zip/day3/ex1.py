import pandas as pd

class Employee:
    def __init__(self, name, emp_id, salary):
        self.name = name
        self.emp_id = emp_id
        self.salary = salary

def binary_search_employees(employees, target_id):
    left, right = 0, len(employees) - 1
    while left <= right:
        mid = left + (right - left) // 2
        if employees[mid].emp_id == target_id:
            return employees[mid]
        elif employees[mid].emp_id < target_id:
            left = mid + 1
        else:
            right = mid - 1
    return None

# Read employee data from an Excel file
df = pd.read_excel('EmployeeData.xlsx')

# Create a list of Employee objects
employee_list = []
for index, row in df.iterrows():
    name = row['Name']
    emp_id = row['Employee ID']
    salary = row['Salary']
    employee = Employee(name, emp_id, salary)
    employee_list.append(employee)

# Sort the list of Employee objects based on their IDs
employee_list.sort(key=lambda emp: emp.emp_id)

# Test binary_search_employees function
target_id = 123  # Replace with the ID you want to search for
found_employee = binary_search_employees(employee_list, target_id)

if found_employee:
    print("Employee found:")
    print("Name:", found_employee.name)
    print("ID:", found_employee.emp_id)
    print("Salary:", found_employee.salary)
else:
    print("Employee not found.")

