'''
You are given a list of students, each represented as a
dictionary with the following attributes: name, age, and gpa.
Your task is to sort the list of students based on their GPA
in descending order using the Insertion Sort algorithm.

Example of a student dictionary:

students = [

{"name": "Alice", "age": 20, "gpa": 3.9},

{"name": "Bob", "age": 22, "gpa": 3.7},

{"name": "Charlie", "age": 21, "gpa": 4.0},

{"name": "David", "age": 19, "gpa": 3.5},

]
'''

def insertion_sort(students):
    for i in range(1, len(students)):
        current_student = students[i]
        j = i - 1
        while j >= 0 and current_student["gpa"] > students[j]["gpa"]:
            students[j + 1] = students[j]
            j -= 1
        students[j + 1] = current_student


students = [
    {"name": "Alice", "age": 20, "gpa": 3.9},
    {"name": "Bob", "age": 22, "gpa": 3.7},
    {"name": "Charlie", "age": 21, "gpa": 4.0},
    {"name": "David", "age": 19, "gpa": 3.5},
]


insertion_sort(students)


for student in students:
    print(f"Name: {student['name']}, Age: {student['age']}, GPA: {student['gpa']}")

