import numpy as np
l1=[7,8,6,100,7,9]
print (l1)

avg = np.average(l1)
print(avg)
